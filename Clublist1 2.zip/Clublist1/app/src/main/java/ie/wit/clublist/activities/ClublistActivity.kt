package ie.wit.clublist.activities

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import ie.wit.clublist.R
import ie.wit.clublist.helpers.readImage
import ie.wit.clublist.helpers.readImageFromPath
import ie.wit.clublist.helpers.showImagePicker
import ie.wit.clublist.main.MainApp
import it.wit.clublist.models.ClublistModel
import it.wit.clublist.models.Location
import kotlinx.android.synthetic.main.activity_clublist.*
import kotlinx.android.synthetic.main.activity_clublist.details
import org.jetbrains.anko.AnkoLogger
import org.jetbrains.anko.info
import org.jetbrains.anko.intentFor
import org.jetbrains.anko.toast

class ClublistActivity : AppCompatActivity(), AnkoLogger {

  var clublist = ClublistModel()
  lateinit var app: MainApp
  val IMAGE_REQUEST = 1
  val LOCATION_REQUEST = 2

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.activity_clublist)
    toolbarAdd.title = title
    setSupportActionBar(toolbarAdd)
    info("Clublist Activity started..")

    app = application as MainApp
    var edit = false

    if (intent.hasExtra("clublist_edit")) {
      edit = true
      clublist = intent.extras?.getParcelable<ClublistModel>("clublist_edit")!!
      clublistTitle.setText(clublist.title)
      details.setText(clublist.details)
      clublistImage.setImageBitmap(readImageFromPath(this, clublist.image))
      if (clublist.image != null) {
        chooseImage.setText(R.string.change_clublist_image)
      }
      btnAdd.setText(R.string.save_clublist)
    }

    btnAdd.setOnClickListener() {
      clublist.title = clublistTitle.text.toString()
      clublist.details = details.text.toString()
      if (clublist.title.isEmpty()) {
        toast(R.string.enter_clublist_title)
      } else {
        if (edit) {
          app.clublists.update(clublist.copy())
        } else {
          app.clublists.create(clublist.copy())
        }
      }
      info("add Button Pressed: $clublistTitle")
      setResult(AppCompatActivity.RESULT_OK)
      finish()
    }

    chooseImage.setOnClickListener {
      showImagePicker(this, IMAGE_REQUEST)
    }

    clublistLocation.setOnClickListener {
      val location = Location(52.245696, -7.139102, 15f)
      if (clublist.zoom != 0f) {
        location.lat = clublist.lat
        location.lng = clublist.lng
        location.zoom = clublist.zoom
      }
      startActivityForResult(intentFor<MapActivity>().putExtra("location", location), LOCATION_REQUEST)
    }
  }

  override fun onCreateOptionsMenu(menu: Menu?): Boolean {
    menuInflater.inflate(R.menu.menu_clublist, menu)
    return super.onCreateOptionsMenu(menu)
  }

  override fun onOptionsItemSelected(item: MenuItem): Boolean {
    when (item.itemId) {
      R.id.item_cancel -> {
        finish()
      }
    }
    return super.onOptionsItemSelected(item)
  }

  override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
    super.onActivityResult(requestCode, resultCode, data)
    when (requestCode) {
      IMAGE_REQUEST -> {
        if (data != null) {
          clublist.image = data.getData().toString()
          clublistImage.setImageBitmap(readImage(this, resultCode, data))
          chooseImage.setText(R.string.change_clublist_image)
        }
      }
      LOCATION_REQUEST -> {
        if (data != null) {
          val location = data.extras?.getParcelable<Location>("location")!!
          clublist.lat = location.lat
          clublist.lng = location.lng
          clublist.zoom = location.zoom
        }
      }
    }
  }
}

